const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Book = new Schema({
    name : {
        type:String
    },
    address : {
        type:String
    },
    phone : {
        type:Number
    },
    instrument : {
        type:String
    },
    joiningDate : {
        type:String
    },
},{
    collection:'books'
});

module.exports = mongoose.model('Book', Book)