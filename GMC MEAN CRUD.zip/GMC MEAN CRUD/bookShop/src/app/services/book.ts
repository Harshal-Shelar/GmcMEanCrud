export class Book {
    _id!: String;
    name!: String;
    address!: String;
    phone!: Number;
    instrument! :String;
    joiningDate! : String
}


