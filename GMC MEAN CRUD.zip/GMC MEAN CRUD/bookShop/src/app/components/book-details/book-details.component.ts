import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CrudService } from 'src/app/services/crud.service';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {

  getId: any;
  updateForm!: FormGroup;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private crudApi: CrudService,
    private activatedRoute: ActivatedRoute) {
    this.getId = this.activatedRoute.snapshot.paramMap.get('id');
    this.crudApi.getBook(this.getId).subscribe(res => {
      this.updateForm.setValue({
        name: res['name'],
        address: res['address'],
        phone: res['phone'],
        instrument: res['instrument'],
        joiningDate: res['joiningDate']
      })
    });

    this.updateForm = this.formBuilder.group({
      name: [''],
      address: [''],
      phone: [''],
      instrument: [''],
      joiningDate: ['']
    })
  }

  ngOnInit(): void {
  }

  onUpdate() {
    this.crudApi.updateBook(this.getId, this.updateForm.value).subscribe(res => {
      console.log("data updated successfully");
      this.ngZone.run(() => {
        this.router.navigateByUrl('/books-list');

      }, (error: any) => {
        console.log(error);

      })
    })

  }

}
