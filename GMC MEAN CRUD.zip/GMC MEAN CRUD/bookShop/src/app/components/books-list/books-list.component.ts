import { Component, OnInit } from '@angular/core';
import { CrudService } from 'src/app/services/crud.service';

@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit {

  Books:any=[];
  constructor(private curdApi: CrudService) { }

  ngOnInit(): void {
    this.curdApi.getBooks().subscribe(res=>{
      console.log(res);
      this.Books = res;
      
    })
  }

  delete(id:any , i:any){ 
    console.log(id);
    if(window.confirm('are you sure want to delete ')){
      this.curdApi.deleteBook(id).subscribe(res=>{
        this.Books.splice(i, 1)
      })
    }

  }

}
